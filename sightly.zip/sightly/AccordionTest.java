package com.mycompany.myproject.sightly;

import org.junit.Test;

import com.mycompany.myproject.sightly.accordion.Accordion;

import static org.junit.Assert.*;

public class AccordionTest {

	/**
	 * Test of setSeeLess method, of class Accordion.
	 */
	@Test
	public void testSetSeeLess() {
	    System.out.println("setSeeLess");
	    String seeLessValue = "setSeeLess";
	    Accordion instance = new Accordion();
	    instance.setSeeLess(seeLessValue);
	    // TODO review the generated test code and remove the default call to fail.
	    assertEquals(instance.getSeeLess(), seeLessValue);
	}

	/**
	 * Test of getSeeLess method, of class Accordions.
	 */
	@Test
	public void testGetSeeLess() {
	    System.out.println("setSeeLess");
	    Accordion instance = new Accordion();
	    String expResult = "getSeeLess";
	    instance.setSeeLess("getSeeLess");
	    String result = instance.getSeeLess();
	    assertEquals(expResult, result);
	}

	
	/**
	 * Test of setSeeMore method, of class Accordion.
	 */
	@Test
	public void testSetSeeMore() {
	    System.out.println("setSeeMore");
	    String seeMoreValue = "setSeeMore";
	    Accordion instance = new Accordion();
	    instance.setSeeMore(seeMoreValue);
	    // TODO review the generated test code and remove the default call to fail.
	    assertEquals(instance.getSeeMore(), seeMoreValue);
	}
	
}
