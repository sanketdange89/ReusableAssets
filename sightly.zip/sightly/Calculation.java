package com.mycompany.myproject.sightly;

public class Calculation {
	
public static int add(int a, int b) {
return a + b;
}

public static int sub(int a, int b) {
return a - b;
}
}
