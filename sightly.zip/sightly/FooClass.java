package com.mycompany.myproject.sightly;

public class FooClass {

	String greet() {

		return "Hello World Class";

	}

}
