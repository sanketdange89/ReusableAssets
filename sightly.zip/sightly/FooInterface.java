package com.mycompany.myproject.sightly;

public interface FooInterface {

	    String HELLO_WORLD_INTERFACE = "Hello World Interface";

	    String greet();

	}
