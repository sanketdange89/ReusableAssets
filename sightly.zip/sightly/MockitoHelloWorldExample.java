package com.mycompany.myproject.sightly;

import static com.mycompany.myproject.sightly.FooInterface.*;

import static org.mockito.Mockito.*;

import org.junit.Test;
import static org.junit.Assert.*;

public class MockitoHelloWorldExample {

	@Test
	public void fooGreets() {

		FooInterface foointerface = mock(FooInterface.class);
		
		FooClass fooclass = mock(FooClass.class);

		when(foointerface.greet()).thenReturn(HELLO_WORLD_INTERFACE);

		System.out.println("FooInterface greets: " + foointerface.greet());

		assertEquals(foointerface.greet(), HELLO_WORLD_INTERFACE);
		
		when(fooclass.greet()).thenReturn("Hello World Class");

		System.out.println("FooClass greets: " + fooclass.greet());

		assertEquals(fooclass.greet(), "Hello World Class");

	}

}
