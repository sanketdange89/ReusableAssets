package com.mycompany.myproject.sightly;

public class MyUnit {

    public String concatenate(String one, String two){
        return one + two;
    }
    
    public Integer testIntegerConcatenate(Integer one, Integer two){
        return one + two;
    }
}
