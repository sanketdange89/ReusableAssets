package com.mycompany.myproject.sightly;

import org.junit.Test;
import static org.junit.Assert.*;

public class MyUnitTest {

    @Test
    public void testConcatenate() {
        MyUnit myUnit = new MyUnit();

        String result = myUnit.concatenate("one", "two");

        assertEquals("onetwo", result);

    }
    
    @Test
    public void testIntegerConcatenate() {
        MyUnit myUnit = new MyUnit();

        int result = myUnit.testIntegerConcatenate(1, 2);

        assertEquals(3, result);
}
}
