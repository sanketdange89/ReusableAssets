package com.mycompany.myproject.sightly;

import static org.junit.Assert.*;

import org.junit.Test;

public class SimpleUnitTest {

    @Test
    public void someTest() {
        assertTrue(true);
    }

}